package com.application.shanuun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShanuunApplicationTests {

	@Test
	void contextLoads() {
	}

}
